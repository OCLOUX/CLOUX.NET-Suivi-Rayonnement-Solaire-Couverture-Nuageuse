=== CLOUX.NET Suivi solaire ===
Stable tag: 3.1.11
Requires PHP: 7.4
License: GPLv2 or later

3.1.9 : correction des graphiques solaires.
- Courbe principale : shortwave_radiation, rayonnement global horizontal (W/m²).
- Rétablissement : diffuse_radiation_instant, rayonnement diffus instantané (W/m²).
- Couverture nuageuse conservée.
- Nouveau graphique quotidien : shortwave_radiation_sum (MJ/m²), trois jours.
- Le graphique quotidien reste visible indépendamment des filtres horaires.
- Les valeurs absentes ne sont pas converties en zéro.
- Deux colonnes de rayonnement dans le tableau horaire.
- Cache météo renouvelé (omw_319_).

Installation : sauvegarder puis téléverser le ZIP dans Extensions > Ajouter
une extension ; remplacer la version existante, sans activer une seconde copie.
Shortcodes : [suivi_solaire] et [openmeteo_weather].

3.1.10 : suppression du paragraphe explicatif du graphique quotidien.
3.1.11 : suppression du paragraphe Courbe principale avant les graphiques.
Données, ordre et quatre graphiques conservés.
