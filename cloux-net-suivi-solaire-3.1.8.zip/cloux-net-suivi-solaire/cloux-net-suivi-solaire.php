<?php
/**
 * Plugin Name: CLOUX.NET Suivi solaire
 * Description: Suivi solaire et météo Open-Meteo : localisation modifiable (ville ou GPS), fenêtre J-1 / journée en cours / J+1, graphiques avec infobulles et tableau horaire. Shortcodes [suivi_solaire] et [openmeteo_weather].
 * Version: 3.1.8
 * Requires PHP: 7.4
 * License: GPLv2 or later
 *
 * Usage :
 *   [suivi_solaire]                                → défaut : 48.7649, 1.9292 (Maurepas), J-1 → J+1
 *   [suivi_solaire location="Versailles"]           → géocodage par nom de ville
 *   [suivi_solaire location="48.8, 2.13"]           → position GPS
 *   [suivi_solaire location="Versailles" start="2026-10-26" end="2026-10-27" charts="1" cache="15"]
 *
 * - location     : nom de ville OU « latitude, longitude » (défaut : 48.7649, 1.9292)
 * - start / end  : dates YYYY-MM-DD (défaut : J-1 → J+1)
 * - label        : titre affiché (défaut : ville ou coordonnées)
 * - charts       : 1 = graphiques SVG (défaut), 0 = tableau seul
 * - cache        : durée du cache en minutes (défaut : 15)
 *
 * Le visiteur peut changer la localisation (ville ou GPS) via le formulaire du widget ;
 * le rafraîchissement passe par l'API REST /wp-json/cloux-solaire/v1/widget.
 *
 * Données : Open-Meteo.com — licence CC BY 4.0 (attribution requise).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Rendu principal des shortcodes [suivi_solaire] et [openmeteo_weather].
 *
 * @param array $atts Attributs du shortcode.
 * @return string HTML échappé.
 */
function omw_render_shortcode( $atts ) {
	$atts = shortcode_atts(
		array(
			'location' => '',
			'lat'      => '48.7649',
			'lon'      => '1.9292',
			'start'    => '',
			'end'      => '',
			'label'    => '',
			'charts'   => '1',
			'cache'    => '15',
		),
		$atts,
		'suivi_solaire'
	);

	$cache_min = max( 1, (int) $atts['cache'] );

	if ( '' !== $atts['start'] && ! omw_valid_date( $atts['start'] ) ) {
		return omw_error( 'Paramètre start invalide : format attendu YYYY-MM-DD.' );
	}
	if ( '' !== $atts['end'] && ! omw_valid_date( $atts['end'] ) ) {
		return omw_error( 'Paramètre end invalide : format attendu YYYY-MM-DD.' );
	}

	// Fenêtre par défaut : J-1 → J+1.
	$today = current_time( 'Y-m-d' );
	$start = '' !== $atts['start'] ? $atts['start'] : gmdate( 'Y-m-d', strtotime( $today . ' -1 day' ) );
	$end   = '' !== $atts['end'] ? $atts['end'] : gmdate( 'Y-m-d', strtotime( $today . ' +1 day' ) );
	if ( $end < $start ) {
		return omw_error( 'Période invalide : la date de fin est antérieure à la date de début.' );
	}

	// Résolution de la localisation : « lat, lon », nom de ville, ou attributs lat/lon.
	$loc = trim( (string) $atts['location'] );
	if ( '' !== $loc ) {
		$resolved = omw_resolve_location( $loc );
		if ( is_wp_error( $resolved ) ) {
			return omw_error( $resolved->get_error_message() );
		}
		$lat = $resolved['lat'];
		$lon = $resolved['lon'];
		$label = '' !== trim( (string) $atts['label'] ) ? $atts['label'] : $resolved['label'];
	} else {
		$lat = filter_var( $atts['lat'], FILTER_VALIDATE_FLOAT );
		$lon = filter_var( $atts['lon'], FILTER_VALIDATE_FLOAT );
		if ( false === $lat || false === $lon || ! omw_valid_coords( $lat, $lon ) ) {
			return omw_error( 'Coordonnées invalides (lat/lon).' );
		}
		$label = '' !== trim( (string) $atts['label'] ) ? $atts['label'] : $lat . ', ' . $lon;
	}

	$content = omw_build_content( $lat, $lon, $label, $start, $end, (string) $atts['charts'], $cache_min );
	if ( is_wp_error( $content ) ) {
		return omw_error( $content->get_error_message() );
	}

	return omw_widget_shell( $content, $start, $end, (string) $atts['charts'] );
}
add_shortcode( 'suivi_solaire', 'omw_render_shortcode' );
add_shortcode( 'openmeteo_weather', 'omw_render_shortcode' );

/**
 * Enveloppe du widget : style + script (une fois), formulaire de localisation, contenu.
 *
 * @param string $content HTML du contenu.
 * @param string $start   Date de début.
 * @param string $end     Date de fin.
 * @param string $charts  Graphiques affichés.
 * @return string
 */
function omw_widget_shell( $content, $start, $end, $charts ) {
 static $style_printed=false; static $script_printed=false; static $id=0; $id++;
 $today=current_time('Y-m-d'); $ctx=omw_context(); $day=$ctx['day']??$today;
 $out='<div class="omw-widget" data-rest="'.esc_attr(rest_url('cloux-solaire/v1/widget')).'" data-charts="'.esc_attr($charts).'" data-today="'.esc_attr($today).'">';
 if(!$style_printed){$out.=omw_styles();$style_printed=true;}
 $out.='<form class="omw-loc-form" autocomplete="off"><label for="omw-loc-'.$id.'" class="omw-loc-label">Sélectionner votre propre emplacement :</label><input type="text" id="omw-loc-'.$id.'" class="omw-loc-input" placeholder="Ville ou GPS (défaut Maurepas)" title="Saisissez une ville ou des coordonnées latitude, longitude. Emplacement par défaut : Maurepas."><button type="submit" class="omw-btn omw-loc-btn">Changer</button><span class="omw-loc-status" role="status" aria-live="polite"></span></form>';
 $out.='<form class="omw-date-form omw-period"><label for="omw-date-'.$id.'" class="omw-period-title">Période :</label><button type="button" class="omw-btn omw-today-btn" data-reset="1">Aujourd’hui</button><span class="omw-calendar-controls"><button type="button" class="omw-btn" data-step="-1" aria-label="Jour précédent"'.($day<=omw_shift($today,-92)?' disabled':'').'>◀</button><input type="date" required id="omw-date-'.$id.'" class="omw-date" min="'.esc_attr(omw_shift($today,-92)).'" max="'.esc_attr($today).'" value="'.esc_attr($day).'"><button type="button" class="omw-btn" data-step="1" aria-label="Jour suivant"'.($day>=$today?' disabled':'').'>▶</button></span><span class="omw-date-status" role="status" aria-live="polite"></span></form>';
 $out.='<div class="omw-content">'.$content.'</div>';
 if(!$script_printed){$out.=omw_script();$script_printed=true;}
 return $out.'</div>';
}

/**
 * Résout une localisation « latitude, longitude » ou nom de ville.
 *
 * @param string $location Saisie utilisateur.
 * @return array|WP_Error Tableau (lat, lon, label) ou erreur.
 */
function omw_resolve_location( $location ) {
	$location = sanitize_text_field( $location );
	if ( '' === $location || strlen( $location ) > 100 ) {
		return new WP_Error( 'omw_loc', 'Localisation manquante ou trop longue.' );
	}
	if ( preg_match( '/^\s*(-?\d{1,2}(?:\.\d+)?)\s*,\s*(-?\d{1,3}(?:\.\d+)?)\s*$/', $location, $m ) ) {
		$lat = (float) $m[1];
		$lon = (float) $m[2];
		if ( ! omw_valid_coords( $lat, $lon ) ) {
			return new WP_Error( 'omw_loc', 'Coordonnées GPS invalides.' );
		}
		return array( 'lat' => $lat, 'lon' => $lon, 'label' => $lat . ', ' . $lon );
	}
	return omw_geocode( $location );
}

/**
 * Point d'entrée REST : /wp-json/cloux-solaire/v1/widget?location=...
 *
 * @param WP_REST_Request $request Requête.
 * @return array|WP_Error HTML du contenu ou erreur.
 */
function omw_rest_widget( $request ) {
 $params=$request->get_params();
 $location=isset($params['location'])?sanitize_text_field((string)$params['location']):'';
 if(''===$location||strlen($location)>100){return new WP_Error('omw_loc','Localisation manquante ou trop longue.',array('status'=>400));}
 $today=current_time('Y-m-d');
 $selected=isset($params['day'])?(string)$params['day']:$today;
 if(!omw_valid_date($selected)||$selected<omw_shift($today,-92)||$selected>$today){
  return new WP_Error('omw_day','Date hors période disponible : J−92 à aujourd’hui.',array('status'=>400));
 }
 $resolved=omw_resolve_location($location);
 if(is_wp_error($resolved)){return new WP_Error('omw_loc',$resolved->get_error_message(),array('status'=>400));}
 $start=max(omw_shift($today,-92),omw_shift($selected,-1)); $end=omw_shift($selected,1);
 $charts=isset($params['charts'])&&'0'===(string)$params['charts']?'0':'1';
 $html=omw_build_content($resolved['lat'],$resolved['lon'],$resolved['label'],$start,$end,$charts,15,$selected);
 if(is_wp_error($html)){return new WP_Error('omw_render',$html->get_error_message(),array('status'=>502));}
 return array('html'=>$html,'day'=>$selected);
}

/**
 * Enregistre la route REST.
 */
function omw_register_rest_route() {
	register_rest_route(
		'cloux-solaire/v1',
		'/widget',
		array(
			'methods'             => 'GET',
			'callback'            => 'omw_rest_widget',
			'permission_callback' => '__return_true',
		)
	);
}
add_action( 'rest_api_init', 'omw_register_rest_route' );

/**
 * Construit le contenu du widget (sans style/script) : récupération + rendu.
 *
 * @param float  $lat       Latitude.
 * @param float  $lon       Longitude.
 * @param string $label     Libellé.
 * @param string $start     Date de début.
 * @param string $end       Date de fin.
 * @param string $charts    « 1 » pour les graphiques.
 * @param int    $cache_min Minutes de cache.
 * @return string|WP_Error
 */
function omw_build_content( $lat, $lon, $label, $start, $end, $charts, $cache_min = 15, $selected = '' ) {
 $today=current_time('Y-m-d'); $minimum=omw_shift($today,-92); $maximum=omw_shift($today,15);
 if(!omw_valid_date($start)||!omw_valid_date($end)||$start<$minimum||$end>$maximum||$end<$start||(strtotime($end)-strtotime($start))>4*86400) {
  return new WP_Error('omw_range','Période hors limites ou supérieure à cinq jours.');
 }
 if(''===$selected){$selected=($start<=$today&&$end>=$today)?$today:$start;}
 if($selected<$minimum||$selected>$today){return new WP_Error('omw_day','Date hors période disponible : J−92 à aujourd’hui.');}
 omw_context(array('day'=>$selected,'location'=>$lat.', '.$lon));
 $cache_key='omw_318_'.md5($lat.'|'.$lon.'|'.$start.'|'.$end);
 $data=get_transient($cache_key);
 if(false===$data||!is_array($data)){
  $data=omw_fetch($lat,$lon,$start,$end); if(is_wp_error($data)){return $data;}
  set_transient($cache_key,$data,max(1,(int)$cache_min)*MINUTE_IN_SECONDS);
 }
 $available=false;
 foreach(($data['hourly']['time']??array()) as $i=>$time){
  if(substr($time,0,10)===$selected && (null!==($data['hourly']['cloud_cover'][$i]??null)||null!==($data['hourly']['shortwave_radiation'][$i]??null))){$available=true;break;}
 }
 if(!$available){return new WP_Error('omw_empty','Aucune donnée disponible pour le jour sélectionné.');}
 return omw_render($data,$label,$charts);
}

/**
 * Géocode un nom de ville via l'API Open-Meteo (mise en cache 24 h).
 *
 * @param string $name Nom de la ville.
 * @return array|WP_Error Tableau (lat, lon, label) ou erreur.
 */
function omw_geocode( $name ) {
	$name = sanitize_text_field( $name );
	if ( '' === $name ) {
		return new WP_Error( 'omw_geo', 'Nom de localisation vide.' );
	}

	$cache_key = 'omw_geo_' . md5( $name );
	$cached    = get_transient( $cache_key );
	if ( false !== $cached && is_array( $cached ) ) {
		return $cached;
	}

	$url = add_query_arg(
		array(
			'name'     => $name,
			'count'    => 1,
			'language' => 'fr',
			'format'   => 'json',
		),
		'https://geocoding-api.open-meteo.com/v1/search'
	);

	$response = wp_remote_get( $url, array( 'timeout' => 8, 'sslverify' => true ) );
	if ( is_wp_error( $response ) ) {
		return new WP_Error( 'omw_geo_http', 'Impossible de joindre le service de géocodage Open-Meteo.' );
	}
	if ( 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
		return new WP_Error( 'omw_geo_http', 'Erreur du service de géocodage Open-Meteo (HTTP ' . (int) wp_remote_retrieve_response_code( $response ) . ').' );
	}
	$json = json_decode( (string) wp_remote_retrieve_body( $response ), true );
	if ( ! is_array( $json ) || empty( $json['results'][0]['latitude'] ) ) {
		return new WP_Error( 'omw_geo_404', 'Localisation introuvable : « ' . $name . ' ». Essayez un nom de ville plus précis ou des coordonnées GPS.' );
	}

	$r     = $json['results'][0];
	$parts = array( $r['name'] );
	if ( ! empty( $r['admin1'] ) ) {
		$parts[] = $r['admin1'];
	}
	if ( ! empty( $r['country'] ) ) {
		$parts[] = $r['country'];
	}
	$geo = array(
		'lat'   => (float) $r['latitude'],
		'lon'   => (float) $r['longitude'],
		'label' => implode( ', ', $parts ),
	);
	set_transient( $cache_key, $geo, 24 * HOUR_IN_SECONDS );
	return $geo;
}

/**
 * Valide une paire de coordonnées.
 *
 * @param float $lat Latitude.
 * @param float $lon Longitude.
 * @return bool
 */
function omw_valid_coords( $lat, $lon ) {
	return ( $lat >= -90 && $lat <= 90 && $lon >= -180 && $lon <= 180 );
}

/**
 * Valide une date YYYY-MM-DD.
 *
 * @param string $date Date candidate.
 * @return bool
 */
function omw_valid_date( $date ) {
	if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) {
		return false;
	}
	$parts = explode( '-', $date );
	return checkdate( (int) $parts[1], (int) $parts[2], (int) $parts[0] );
}

/**
 * Appelle l'API Open-Meteo et décode la réponse.
 *
 * @param float  $lat   Latitude.
 * @param float  $lon   Longitude.
 * @param string $start Date de début.
 * @param string $end   Date de fin.
 * @return array|WP_Error Données ou erreur.
 */
function omw_fetch( $lat, $lon, $start, $end ) {
	$url = add_query_arg(
		array(
			'latitude'   => $lat,
			'longitude'  => $lon,
			'daily'      => 'sunrise,sunset,daylight_duration,sunshine_duration,shortwave_radiation_sum',
			'hourly'     => 'cloud_cover,shortwave_radiation',
			'models'     => 'best_match',
			'current'    => 'is_day',
			'timezone'   => 'auto',
			'start_date' => $start,
			'end_date'   => $end,
		),
		'https://api.open-meteo.com/v1/forecast'
	);

	$response = wp_remote_get( $url, array( 'timeout' => 8, 'sslverify' => true ) );
	if ( is_wp_error( $response ) ) {
		return new WP_Error( 'omw_http', 'Impossible de joindre api.open-meteo.com (' . $response->get_error_message() . ').' );
	}
	$code = (int) wp_remote_retrieve_response_code( $response );
	if ( 200 !== $code ) {
		$reason = omw_api_reason( (string) wp_remote_retrieve_body( $response ) );
		return new WP_Error( 'omw_http_' . $code, 'Erreur API Open-Meteo (HTTP ' . $code . ') : ' . $reason );
	}
	$data = json_decode( (string) wp_remote_retrieve_body( $response ), true );
	if ( ! is_array( $data ) || ! isset( $data['hourly']['time'] ) ) {
		return new WP_Error( 'omw_json', 'Réponse Open-Meteo illisible ou inattendue.' );
	}
	return $data;
}

/**
 * Extrait le motif d'erreur JSON renvoyé par Open-Meteo.
 *
 * @param string $body Corps brut de la réponse.
 * @return string
 */
function omw_api_reason( $body ) {
	$json = json_decode( $body, true );
	if ( isset( $json['reason'] ) ) {
		return sanitize_text_field( (string) $json['reason'] );
	}
	return 'raison inconnue';
}

/**
 * Bloc d'erreur affichable.
 *
 * @param string $message Message.
 * @return string
 */
function omw_error( $message ) {
	return '<p class="omw-error" style="color:#b3261e;">' . esc_html( $message ) . '</p>';
}

/**
 * Convertit des secondes en « X h Y min » (arrondi à la minute).
 *
 * @param mixed $seconds Durée en secondes.
 * @return string
 */

function omw_shift($date,$days) { return gmdate('Y-m-d',strtotime($date.' UTC')+$days*86400); }
function omw_context($set=null) { static $ctx=array(); if(null!==$set){$ctx=$set;} return $ctx; }
function omw_future($time) { $ctx=omw_context(); return $time>($ctx['now']??current_time('Y-m-d\TH:i')); }
function omw_compact_date($date) {
 $names=array('Dim.','Lun.','Mar.','Mer.','Jeu.','Ven.','Sam.');
 return esc_html($names[(int)gmdate('w',strtotime($date.' UTC'))].' '.substr($date,8,2).'/'.substr($date,5,2).'/'.substr($date,0,4));
}

function omw_duration( $seconds ) {
	if ( null === $seconds || '' === $seconds ) {
		return '—';
	}
	$minutes = (int) round( (float) $seconds / 60 );
	$h       = intdiv( $minutes, 60 );
	$m       = $minutes % 60;
	return $h . 'h' . str_pad( (string) $m, 2, '0', STR_PAD_LEFT );
}

/**
 * Formate « YYYY-MM-DD » en date française longue (sans dépendre de l'extension intl).
 *
 * @param string $date Date.
 * @return string
 */
function omw_date_fr( $date ) {
	if ( ! preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', (string) $date, $m ) ) {
		return esc_html( (string) $date );
	}
	$jours = array( 'dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi' );
	$mois  = array( 1 => 'janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre' );
	$ts = gmmktime( 12, 0, 0, (int) $m[2], (int) $m[3], (int) $m[1] );
	if ( false === $ts ) {
		return esc_html( (string) $date );
	}
	$dow = (int) gmdate( 'w', $ts );
	return esc_html( $jours[ $dow ] . ' ' . (int) $m[3] . ' ' . $mois[ (int) $m[2] ] . ' ' . $m[1] );
}

/**
 * Étiquette relative d'un jour : J-1, Journée en cours, J+1 (prévision).
 *
 * @param string $date Date YYYY-MM-DD.
 * @return string Vide si le jour n'est pas J-1/J/J+1.
 */
function omw_day_badge( $date ) {
	$today = current_time( 'Y-m-d' );
	if ( $date === $today ) {
		return 'Aujourd’hui';
	}
	if ( $date === gmdate( 'Y-m-d', strtotime( $today . ' -1 day' ) ) ) {
		return 'J-1';
	}
	if ( $date === gmdate( 'Y-m-d', strtotime( $today . ' +1 day' ) ) ) {
		return 'J+1 (prévision)';
	}
	return '';
}

/**
 * Extrait « HH:MM » d'une chaîne ISO « YYYY-MM-DDTHH:MM ».
 *
 * @param string $iso Horodatage ISO.
 * @return string
 */
function omw_hhmm( $iso ) {
	$iso = (string) $iso;
	if ( strlen( $iso ) < 16 ) {
		return '—';
	}
	return esc_html( substr( $iso, 11, 5 ) );
}

/**
 * Formate « YYYY-MM-DDTHH:MM » en « JJ/MM/YYYY à HH:MM ».
 *
 * @param string $iso Horodatage ISO.
 * @return string
 */
function omw_fulltime( $iso ) {
	$iso = (string) $iso;
	if ( ! preg_match( '/^(\d{4})-(\d{2})-(\d{2})T(\d{2}:\d{2})$/', $iso, $m ) ) {
		return '—';
	}
	return esc_html( $m[3] . '/' . $m[2] . '/' . $m[1] . ' à ' . $m[4] );
}

/**
 * Horodatage Unix (ms) d'une heure ISO « YYYY-MM-DDTHH:MM ».
 *
 * @param string $iso Heure ISO.
 * @return int
 */
function omw_ts( $iso ) {
 if (''===(string)$iso) {return 0;}
 try { $ctx=omw_context(); $zone=new DateTimeZone($ctx['timezone']??'UTC'); return (new DateTimeImmutable((string)$iso,$zone))->getTimestamp()*1000; }
 catch(Exception $e) {return 0;}
}

/**
 * Rendu du contenu : en-tête, cartes, graphiques, tableau.
 *
 * @param array  $data   Données Open-Meteo.
 * @param string $label  Libellé de la localisation.
 * @param string $charts « 1 » pour afficher les graphiques.
 * @return string
 */
function omw_render( $data, $label, $charts ) {
 $tz=isset($data['timezone'])?(string)$data['timezone']:'UTC';
 try{$zone=new DateTimeZone($tz==='auto'?'UTC':$tz);}catch(Exception $e){$zone=new DateTimeZone('UTC');}
 $ctx=omw_context(); $ctx['timezone']=$zone->getName(); $ctx['now']=(new DateTimeImmutable('now',$zone))->format('Y-m-d\TH:i'); omw_context($ctx);
 $day=$ctx['day']; $now=(string)($data['current']['time']??'');
 $out='<div class="omw-context" data-location="'.esc_attr($ctx['location']).'" data-day="'.esc_attr($day).'"></div>';
 $out.='<div class="omw-head"><p class="omw-summary"><span class="omw-location">'.esc_html($label).'</span> <span class="omw-summary-meta">Fuseau '.esc_html($tz);
 if(''!==$now){$out.=' · état courant ('.omw_fulltime($now).')';}
 $out.='</span></p></div><div class="omw-days">';
 $daily=$data['daily']??array(); $dates=$daily['time']??array();
 foreach(array(omw_shift($day,-1),$day,omw_shift($day,1)) as $date){
  $i=array_search($date,$dates,true);
  $badge=omw_day_badge($date);
  if(''===$badge){$badge=$date===$day?'Jour sélectionné':($date<$day?'Jour précédent':'Jour suivant');}
  $out.='<div class="omw-day"><p class="omw-day-date">'.omw_compact_date($date).'</p><p class="omw-badge">'.esc_html($badge).'</p>';
  if($date<omw_shift(current_time('Y-m-d'),-92)){$out.='<p class="omw-unavailable">Hors période disponible</p></div>';continue;}
  $out.='<ul>';
  $out.='<li><span>Lever</span><strong>'.omw_hhmm(false===$i?'':($daily['sunrise'][$i]??'')).'</strong></li>';
  $out.='<li><span>Coucher</span><strong>'.omw_hhmm(false===$i?'':($daily['sunset'][$i]??'')).'</strong></li>';
  $out.='<li><span>Jour</span><strong>'.esc_html(omw_duration(false===$i?null:($daily['daylight_duration'][$i]??null))).'</strong></li>';
  $out.='<li><span title="Durée d’ensoleillement">Soleil</span><strong>'.esc_html(omw_duration(false===$i?null:($daily['sunshine_duration'][$i]??null))).'</strong></li>';
  $out.='<li><span title="shortwave_radiation_sum : énergie solaire globale reçue sur la journée">Énergie solaire</span><strong>'.omw_num(false===$i?null:($daily['shortwave_radiation_sum'][$i]??null)).' MJ/m²</strong></li></ul></div>';
 }
 $out.='</div>';
 $out.='<p class="omw-radiation-note">Courbe principale : rayonnement global horizontal (shortwave_radiation), moyenne sur l’heure précédente en W/m². Cumul journalier : shortwave_radiation_sum en MJ/m². Ces données ne sont pas une mesure de production électrique du panneau.</p>';
 if('0'!==$charts&&!empty($data['hourly']['time'])){$out.=omw_render_charts($data['hourly']);}
 $out.=omw_table($data['hourly']??array(),$ctx['now']);
 return $out.'<p class="omw-attribution">Données : <a href="https://open-meteo.com/" rel="noopener">Open-Meteo.com</a> (modèles « best match », licence CC BY 4.0).</p>';
}

/**
 * Filtre les données horaires sur un jour précis.
 *
 * @param array  $hourly Données horaires.
 * @param string $day    Date YYYY-MM-DD.
 * @return array
 */
function omw_filter_hourly_by_day( $hourly, $day ) {
	$sub = array();
	foreach ( $hourly as $key => $series ) {
		if ( ! is_array( $series ) ) {
			continue;
		}
		$sub[ $key ] = array();
	}
	foreach ( (array) $hourly['time'] as $i => $time ) {
		if ( 0 === strpos( (string) $time, $day ) ) {
			foreach ( $sub as $key => $series ) {
				$sub[ $key ][] = $hourly[ $key ][ $i ] ?? null;
			}
		}
	}
	return $sub;
}

/**
 * Graphiques (rayonnement puis nuages) avec boutons de période et infobulles.
 *
 * @param array $hourly Données horaires.
 * @return string
 */
function omw_render_charts( $hourly ) {
	$today = omw_context()['day'] ?? current_time('Y-m-d');
	$yesterday = gmdate( 'Y-m-d', strtotime( $today . ' -1 day' ) );
	$tomorrow  = gmdate( 'Y-m-d', strtotime( $today . ' +1 day' ) );

	$variants = array(
		'all' => $hourly,
		'j-1' => omw_filter_hourly_by_day( $hourly, $yesterday ),
		'j'   => omw_filter_hourly_by_day( $hourly, $today ),
		'j+1' => omw_filter_hourly_by_day( $hourly, $tomorrow ),
	);
	$labels = array(
		'all' => 'Tout',
		'j-1' => 'Jour précédent',
		'j'   => 'Jour sélectionné',
		'j+1' => 'Jour suivant',
	);

	$rendered = array();
	foreach ( $variants as $key => $sub ) {
		if ( count( (array) ( $sub['time'] ?? array() ) ) >= 2 ) {
			$rendered[ $key ] = $sub;
		}
	}
	if ( empty( $rendered ) ) {
		return '';
	}
	$default_key = isset($rendered['j']) ? 'j' : array_key_first($rendered);

	$out  = '<div class="omw-period omw-chart-period" role="group" aria-label="Période des graphiques">';
	$out .= '<span class="omw-period-label">Graphiques :</span>';
	foreach ( $rendered as $key => $sub ) {
		$active = ( $key === $default_key );
		$out .= '<button type="button" class="omw-btn' . ( $active ? ' is-active' : '' ) . '" data-variant="' . esc_attr( $key ) . '" aria-pressed="' . ( $active ? 'true' : 'false' ) . '">' . esc_html( $labels[ $key ] ) . '</button>';
	}
	$out .= '</div>';

	$out .= '<div class="omw-charts">';
	foreach ( $rendered as $key => $sub ) {
		$active = ( $key === $default_key );
		$out .= '<div class="omw-chart-variant' . ( $active ? ' is-active' : '' ) . '" data-variant="' . esc_attr( $key ) . '">';
		$out .= omw_chart_radiation( $sub );
		$out .= omw_chart_cloud( $sub );
		$out .= '</div>';
	}
	$out .= '</div>';
	return $out;
}

/**
 * Tableau horaire responsive : journée en cours par défaut, plus récent en haut.
 *
 * @param array  $hourly Données horaires.
 * @param string $now    Heure courante ISO (état courant).
 * @return string
 */
function omw_table( $hourly, $now = '' ) {
	if ( empty( $hourly['time'] ) ) {
		return '';
	}
	$today = current_time( 'Y-m-d' );

	$rows = '';
	$times = (array) $hourly['time'];
	for ( $i = count( $times ) - 1; $i >= 0; $i-- ) {
		$time = (string) $times[ $i ];
		$rows .= '<tr class="' . (omw_future($time) ? 'omw-forecast' : 'omw-past') . '"' . (substr($time,0,10) !== (omw_context()['day'] ?? $today) ? ' hidden' : '') . ' data-ts="' . esc_attr( (string) omw_ts( $time ) ) . '" data-date="' . esc_attr( substr( $time, 0, 10 ) ) . '">';
		$rows .= '<th scope="row">' . esc_html( str_replace( 'T', ' ', substr( $time, 5 ) ) ) . '</th>';
		$rows .= '<td>' . omw_num( $hourly['cloud_cover'][ $i ] ?? null ) . '</td>';
		$rows .= '<td>' . omw_num( $hourly['shortwave_radiation'][ $i ] ?? null ) . '</td>';
		$rows .= '</tr>';
	}

	$modes = array(
		'today' => 'Jour sélectionné',
		'24'    => 'Dernières 24 h',
		'48'    => 'Dernières 48 h',
		'48f'   => 'Prévision 48 h',
	);

	$out  = '<div class="omw-table-block">';
	$out .= '<div class="omw-period" role="group" aria-label="Période affichée">';
	$out .= '<span class="omw-period-label">Période :</span>';
	foreach ( $modes as $mode => $label ) {
		$active = ( 'today' === $mode );
		$out .= '<button type="button" class="omw-btn' . ( $active ? ' is-active' : '' ) . '" data-mode="' . esc_attr( $mode ) . '" aria-pressed="' . ( $active ? 'true' : 'false' ) . '">' . esc_html( $label ) . '</button>';
	}
	$out .= '</div>';
	$out .= '<div class="omw-table-wrap"><table class="omw-table" data-now="' . esc_attr( (string) omw_ts( $now ) ) . '" data-today="' . esc_attr( $today ) . '">';
	$out .= '<caption class="screen-reader-text">Données horaires Open-Meteo</caption>';
	$out .= '<thead><tr><th scope="col">Heure</th><th scope="col">Nuages (%)</th><th scope="col">Ray. global horizontal (W/m²)</th></tr></thead>';
	$out .= '<tbody>' . $rows . '</tbody></table></div>';
	$out .= '</div>';
	return $out;
}

/**
 * Formate un nombre ou « — » si absent.
 *
 * @param mixed $value Valeur.
 * @return string
 */
function omw_num( $value ) {
	if ( null === $value || '' === $value ) {
		return '—';
	}
	return esc_html( number_format_i18n( (float) $value, 1 ) );
}

/**
 * Libellé court « JJ/MM HH:MM » d'une heure ISO.
 *
 * @param string $time Heure ISO.
 * @return string
 */
function omw_short_label( $time ) {
	$time = (string) $time;
	if ( strlen( $time ) < 16 ) {
		return '';
	}
	return esc_attr( substr( $time, 8, 2 ) . '/' . substr( $time, 5, 2 ) . ' ' . substr( $time, 11, 5 ) );
}

/**
 * Libellés de dates sous l'axe des graphiques, avec mention « prévision » pour J+1.
 *
 * @param array  $times Heures ISO.
 * @param float  $x1    Abscisse du premier point.
 * @param float  $x2    Abscisse du dernier point.
 * @param float  $y     Ordonnée des libellés.
 * @return string
 */
function omw_date_axis( $times, $x1, $x2, $y ) {
	$today = current_time( 'Y-m-d' );
	$days  = array();
	foreach ( (array) $times as $time ) {
		$d = substr( (string) $time, 0, 10 );
		if ( ! isset( $days[ $d ] ) ) {
			$days[ $d ] = 0;
		}
		$days[ $d ]++;
	}
	$out = '';
	$n = max( 1, count( $times ) - 1 );
	$pos = 0;
	foreach ( $days as $d => $count ) {
		$cx = $x1 + ( $pos + ( $count - 1 ) / 2 ) / $n * ( $x2 - $x1 );
		$label = substr( $d, 8, 2 ) . '/' . substr( $d, 5, 2 );
		if ( $d > $today ) {
			$label .= ' (prévision)';
		}
		$out .= '<text x="' . number_format( $cx, 1 ) . '" y="' . number_format( $y, 1 ) . '" class="omw-axis omw-axis-date" text-anchor="middle">' . esc_html( $label ) . '</text>';
		$pos += $count;
	}
	return $out;
}

/**
 * Zones de survol (infobulles) : une colonne par heure.
 *
 * @param int    $i      Indice de l'heure.
 * @param int    $n      Nombre d'heures.
 * @param float  $x      Abscisse de départ.
 * @param float  $step   Largeur d'une colonne.
 * @param float  $top    Haut de la zone.
 * @param float  $height Hauteur de la zone.
 * @param string $time   Heure ISO.
 * @param string $value  Valeur formatée.
 * @return string
 */
function omw_hit( $i, $n, $x, $step, $top, $height, $time, $value ) {
	$label = omw_short_label( $time );
	return '<rect class="omw-hit" data-label="' . $label . '" data-value="' . esc_attr( $value ) . '" x="' . number_format( $x, 1 ) . '" y="' . number_format( $top, 1 ) . '" width="' . number_format( $step, 1 ) . '" height="' . number_format( $height, 1 ) . '" />';
}

/**
 * Graphique SVG : rayonnement global horizontal, moyenne sur l’heure précédente (W/m²).
 *
 * @param array $hourly Données horaires.
 * @return string
 */
function omw_chart_radiation($hourly) { return omw_chart_series($hourly,'shortwave_radiation','Rayonnement global horizontal','W/m²'); }

/**
 * Graphique SVG : couverture nuageuse (0–100 %).
 *
 * @param array $hourly Données horaires.
 * @return string
 */
function omw_chart_cloud($hourly) { return omw_chart_series($hourly,'cloud_cover','Couverture nuageuse','%'); }

/**
 * Construit un couple aire + ligne pour une série de points contigus.
 *
 * @param array $points Points « x,y ».
 * @param float $base_y Ordonnée de la base.
 * @return string
 */

function omw_svg_num($v) { return number_format($v,2,'.',''); }
function omw_chart_series($hourly,$key,$title,$unit) {
 $times=$hourly['time']??array();$values=$hourly[$key]??array();$n=count($times);if(!$n){return '';}
 $left=42;$right=708;$top=24;$bottom=154;$width=$right-$left;$height=$bottom-$top;$max=100;
 if($key!=='cloud_cover'){$max=50;foreach($values as $v){if(null!==$v&&''!==$v){$max=max($max,ceil((float)$v/50)*50);}}}
 $xof=function($i)use($left,$width,$n){return $left+$width*$i/max(1,$n-1);};
 $out='<figure class="omw-chart"><figcaption>'.esc_html($title.' ('.$unit.')').'</figcaption><svg viewBox="0 0 720 200" role="img" aria-label="'.esc_attr($title).'">';
 $ctx=omw_context();$now=$ctx['now']??current_time('Y-m-d\TH:i');$cut=null;
 if($times[0]>$now){$cut=$left;}else{
  for($i=1;$i<$n;$i++){if($times[$i]>$now){
   $a=omw_ts($times[$i-1]);$b=omw_ts($times[$i]);$t=omw_ts($now);
   $cut=$xof($i-1)+($xof($i)-$xof($i-1))*max(0,min(1,($t-$a)/max(1,$b-$a)));break;
  }}
 }
 if(null!==$cut){$out.='<rect x="'.omw_svg_num($cut).'" y="'.$top.'" width="'.omw_svg_num($right-$cut).'" height="'.$height.'" class="omw-future-bg"/>';}
 foreach(array(0,.25,.5,.75,1) as $f){$y=$bottom-$f*$height;
  $out.='<line x1="'.$left.'" x2="'.$right.'" y1="'.$y.'" y2="'.$y.'" class="omw-grid"/><text x="36" y="'.($y+4).'" text-anchor="end" class="omw-axis">'.(int)($max*$f).'</text>';
 }
 $color=$key==='cloud_cover'?'#4f46e5':'#b77908';
 for($i=1;$i<$n;$i++){
  $v1=$values[$i-1]??null;$v2=$values[$i]??null;if(null===$v1||null===$v2||''===$v1||''===$v2){continue;}
  $x1=$xof($i-1);$x2=$xof($i);$y1=$bottom-(float)$v1/$max*$height;$y2=$bottom-(float)$v2/$max*$height;
  $segments=array(array($x1,$y1,$x2,$y2,omw_future($times[$i-1])));
  if(null!==$cut&&$x1<=$cut&&$x2>$cut){
   $yc=$y1+($y2-$y1)*($cut-$x1)/($x2-$x1);
   $segments=array(array($x1,$y1,$cut,$yc,false),array($cut,$yc,$x2,$y2,true));
  }
  foreach($segments as $seg){$out.='<line x1="'.omw_svg_num($seg[0]).'" y1="'.omw_svg_num($seg[1]).'" x2="'.omw_svg_num($seg[2]).'" y2="'.omw_svg_num($seg[3]).'" stroke="'.$color.'" stroke-width="2"'.($seg[4]?' stroke-dasharray="5 4"':'').'/>';}
 }
 if(null!==$cut&&$cut>$left&&$cut<$right){$out.='<line x1="'.omw_svg_num($cut).'" x2="'.omw_svg_num($cut).'" y1="'.$top.'" y2="'.$bottom.'" class="omw-now"/><text x="'.omw_svg_num($cut).'" y="15" text-anchor="middle" class="omw-axis">Maintenant</text>';}
 $slot=$width/max(1,$n-1);
 foreach($times as $i=>$time){$x=$xof($i);
  if($i%6===0){$out.='<text x="'.omw_svg_num($x).'" y="174" text-anchor="middle" class="omw-axis">'.esc_html(substr($time,11,5)).'</text>';}
  $v=$values[$i]??null;$value=(null===$v||''===$v?'—':number_format_i18n((float)$v,1).' '.$unit).' · '.(omw_future($time)?'Prévision':'Donnée passée — modèle');
  $out.=omw_hit($i,$n,max($left,$x-$slot/2),min($right,$x+$slot/2)-max($left,$x-$slot/2),$top,$height,$time,$value);
 }
 $out.=omw_date_axis($times,$left,$right,194);
 return $out.'</svg></figure>';
}

function omw_cloud_path( $points, $base_y ) {
	if ( count( $points ) < 2 ) {
		return '';
	}
	$polyline = implode( ' ', $points );
	$first_x  = explode( ',', $points[0] )[0];
	$last_x   = explode( ',', $points[ count( $points ) - 1 ] )[0];
	$area = 'M ' . $first_x . ' ' . $base_y . ' L ' . $polyline . ' L ' . $last_x . ' ' . $base_y . ' Z';
	return '<path d="' . esc_attr( $area ) . '" class="omw-area" />'
		. '<polyline points="' . esc_attr( $polyline ) . '" class="omw-line" />';
}

/**
 * Script : filtres de période, variantes de graphiques, infobulles, formulaire de localisation.
 *
 * @return string
 */
function omw_script() {
	$js = <<<JS
(function(){
	function applyTable(btn){
		var mode = btn.getAttribute('data-mode');
		var widget = btn.closest('.omw-widget');
		if(!widget){ return; }
		var rows = widget.querySelectorAll('tbody tr[data-ts]');
		if(!rows.length){ return; }
		var table = widget.querySelector('.omw-table');
		var now = table ? +(table.getAttribute('data-now')||0) : 0;
		if(!now){
			for(var k=0;k<rows.length;k++){ now = Math.max(now, +rows[k].getAttribute('data-ts')); }
		}
		var ctx=widget.querySelector('.omw-context');var today=ctx?ctx.getAttribute('data-day'):widget.getAttribute('data-today');
		var i;
		for(i=0;i<rows.length;i++){
			var ts = +rows[i].getAttribute('data-ts');
			var show;
			if(mode === 'today'){ show = rows[i].getAttribute('data-date') === today; }
			else if(mode === '24'){ show = ts >= now - 86400000 && ts <= now; }
			else if(mode === '48'){ show = ts >= now - 172800000 && ts <= now; }
			else if(mode === '48f'){ show = ts > now && ts <= now + 172800000; }
			else { show = true; }
			rows[i].hidden = !show;
		}
		var btns = widget.querySelectorAll('.omw-btn[data-mode]');
		for(var j=0;j<btns.length;j++){
			btns[j].classList.toggle('is-active', btns[j] === btn);
			btns[j].setAttribute('aria-pressed', btns[j] === btn ? 'true' : 'false');
		}
	}
	function applyVariant(btn){
		var scope = btn.closest('.omw-content') || btn.closest('.omw-widget');
		if(!scope){ return; }
		var v = btn.getAttribute('data-variant');
		var variants = scope.querySelectorAll('.omw-chart-variant');
		for(var i=0;i<variants.length;i++){
			variants[i].classList.toggle('is-active', variants[i].getAttribute('data-variant') === v);
		}
		var btns = scope.querySelectorAll('.omw-btn[data-variant]');
		for(var j=0;j<btns.length;j++){
			btns[j].classList.toggle('is-active', btns[j] === btn);
			btns[j].setAttribute('aria-pressed', btns[j] === btn ? 'true' : 'false');
		}
	}
	function ensureTip(widget){
		var tip = widget.querySelector('.omw-tooltip');
		if(!tip){
			tip = document.createElement('div');
			tip.className = 'omw-tooltip';
			tip.setAttribute('role', 'tooltip');
			widget.appendChild(tip);
		}
		return tip;
	}
 function alignControls(widget){
  var label=widget.querySelector('.omw-loc-label'),form=widget.querySelector('.omw-loc-form'),input=widget.querySelector('.omw-loc-input'),date=widget.querySelector('.omw-date');
  if(!label||!form||!input||!date){return;}
  widget.style.setProperty('--omw-label-width',label.getBoundingClientRect().width+'px');
  widget.style.setProperty('--omw-end-space',Math.max(0,form.getBoundingClientRect().right-input.getBoundingClientRect().right)+'px');
  var font=window.getComputedStyle(input);
  ['fontFamily','fontSize','fontWeight','fontStyle','lineHeight','letterSpacing'].forEach(function(key){date.style[key]=font[key];});
 }
	function initWidget(widget){
  alignControls(widget);
  if(!widget._omwLayoutBound){
   widget._omwLayoutBound=true;
   if(typeof ResizeObserver!=='undefined'){
    widget._omwLayoutObserver=new ResizeObserver(function(){alignControls(widget);});
    ['.omw-loc-form','.omw-loc-label','.omw-loc-input','.omw-loc-btn'].forEach(function(sel){var el=widget.querySelector(sel);if(el){widget._omwLayoutObserver.observe(el);}});
   }else{window.addEventListener('resize',function(){alignControls(widget);});}
   if(document.fonts&&document.fonts.ready){document.fonts.ready.then(function(){alignControls(widget);});}
  }
  var input=widget.querySelector('.omw-date'),ctx=widget.querySelector('.omw-context');
  if(input&&ctx){input.value=ctx.getAttribute('data-day');
   widget.querySelector('[data-step="-1"]').disabled=input.value<=input.min;
   widget.querySelector('[data-step="1"]').disabled=input.value>=input.max;
  }

		var def = widget.querySelector('.omw-btn[data-mode].is-active');
		if(def){ applyTable(def); }
	}
	document.addEventListener('click', function(e){
		var t = e.target;
		var b = t.closest ? t.closest('.omw-btn[data-mode]') : null;
		if(b){ applyTable(b); return; }
		var c = t.closest ? t.closest('.omw-btn[data-variant]') : null;
		if(c){ applyVariant(c); }
	});
	document.addEventListener('mousemove', function(e){
		var t = e.target;
		var hit = t.closest ? t.closest('.omw-hit') : null;
		var tips = document.querySelectorAll('.omw-tooltip');
		if(!hit){
			for(var k=0;k<tips.length;k++){ tips[k].classList.remove('is-visible'); }
			return;
		}
		var widget = hit.closest('.omw-widget');
		if(!widget){ return; }
		var tip = ensureTip(widget);
		tip.textContent = (hit.getAttribute('data-label')||'') + ' · ' + (hit.getAttribute('data-value')||'');
		var rect = widget.getBoundingClientRect();
		tip.style.left = Math.max(4, Math.min(rect.width - 12, e.clientX - rect.left + 14)) + 'px';
		tip.style.top = Math.max(4, e.clientY - rect.top - 34) + 'px';
		tip.classList.add('is-visible');
	});

 function activeLocation(widget){var ctx=widget.querySelector('.omw-context');return ctx?ctx.getAttribute('data-location'):'48.7649, 1.9292';}
 function loadWidget(widget,loc,day,status){
  var input=widget.querySelector('.omw-date');
  if(!day||day<input.min||day>input.max){status.textContent='Date hors période disponible : J−92 à aujourd’hui.';return;}
  if(widget._omwAbort){widget._omwAbort.abort();}
  var controller=new AbortController();widget._omwAbort=controller;
  var params=new URLSearchParams({location:loc,day:day,charts:widget.getAttribute('data-charts')||'1'});
  status.textContent='Chargement…';widget.setAttribute('aria-busy','true');
  fetch(widget.getAttribute('data-rest')+'?'+params.toString(),{signal:controller.signal})
   .then(function(r){return r.json().then(function(j){if(!r.ok||!j.html){throw new Error(j.message||'Réponse API invalide.');}return j;});})
   .then(function(j){
    if(widget._omwAbort!==controller){return;}
    widget.querySelector('.omw-content').innerHTML=j.html;
    widget.querySelector('.omw-loc-input').value=loc;
    widget.querySelectorAll('[role="status"]').forEach(function(el){el.textContent='';});
    status.textContent='Affichage mis à jour.';initWidget(widget);
   }).catch(function(e){if(e.name!=='AbortError'&&widget._omwAbort===controller){status.textContent=e.message||'Erreur réseau.';}})
   .finally(function(){if(widget._omwAbort===controller){widget.removeAttribute('aria-busy');}});
 }
 document.addEventListener('change',function(e){
  var input=e.target;
  if(!input.matches||!input.matches('.omw-date')){return;}
  var widget=input.closest('.omw-widget');if(!widget){return;}
  if(!input.checkValidity()){input.reportValidity();return;}
  loadWidget(widget,activeLocation(widget),input.value,widget.querySelector('.omw-date-status'));
 });
 document.addEventListener('submit',function(e){
  var form=e.target.closest('.omw-loc-form,.omw-date-form');if(!form){return;}e.preventDefault();
  var widget=form.closest('.omw-widget'),isLoc=form.classList.contains('omw-loc-form'),status=form.querySelector('[role="status"]');
  var loc=isLoc?widget.querySelector('.omw-loc-input').value.trim():activeLocation(widget);
  if(!loc){status.textContent='Saisissez une ville ou des coordonnées GPS.';return;}
  var ctx=widget.querySelector('.omw-context');
  var day=isLoc?ctx.getAttribute('data-day'):widget.querySelector('.omw-date').value;
  loadWidget(widget,loc,day,status);
 });
 document.addEventListener('click',function(e){
  var button=e.target.closest('[data-step],[data-reset]');if(!button||button.disabled){return;}
  var widget=button.closest('.omw-widget');if(!widget){return;}
  var ctx=widget.querySelector('.omw-context'),day=widget.getAttribute('data-today');
  if(!button.hasAttribute('data-reset')){var d=new Date(ctx.getAttribute('data-day')+'T12:00:00Z');d.setUTCDate(d.getUTCDate()+Number(button.getAttribute('data-step')));day=d.toISOString().slice(0,10);}
  loadWidget(widget,activeLocation(widget),day,widget.querySelector('.omw-date-status'));
 });
	var widgets = document.querySelectorAll('.omw-widget');
	for(var w=0; w<widgets.length; w++){ initWidget(widgets[w]); }
})();
JS;
	return '<script>' . $js . '</script>';
}

/**
 * Styles CSS (préfixés omw-, imprimés une seule fois).
 *
 * @return string
 */
function omw_styles() {
	$css = <<<CSS
.omw-widget{position:relative;font-family:inherit;color:#1f2937;background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:1.2em 1.2em .8em;margin:1.2em 0;max-width:100%;}
.omw-widget h3.omw-title{margin:0 0 .2em;font-size:1.15em;}
.omw-meta{margin:0 0 .8em;font-size:.85em;color:#475569;}
.omw-loc-form{display:flex;align-items:center;flex-wrap:wrap;gap:.4em;margin:0 0 1em;}
.omw-loc-input{flex:1 1 180px;min-width:0;font-size:.9em;padding:.35em .6em;border:1px solid #c7d2fe;border-radius:.5em;background:#fff;color:#1f2937;}
.omw-loc-input:focus{outline:2px solid #4f46e5;outline-offset:1px;}
.omw-loc-btn{font-size:.8em;padding:.35em .8em;border:1px solid #c7d2fe;border-radius:1em;background:#fff;color:#3730a3;cursor:pointer;}
.omw-loc-btn:hover{background:#eef2ff;}
.omw-loc-status{font-size:.78em;color:#475569;flex-basis:100%;}
.omw-days{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(170px,100%),1fr));gap:.8em;margin:0 0 1em;}
.omw-day{background:#fff;border:1px solid #e2e8f0;border-radius:8px;padding:.7em .9em;}
.omw-day-date{margin:0 0 .2em;font-weight:600;text-transform:capitalize;font-size:.95em;}
.omw-badge{margin:0 0 .4em;display:inline-block;font-size:.72em;font-weight:600;color:#3730a3;background:#eef2ff;border-radius:1em;padding:.1em .6em;}
.omw-day ul{list-style:none;margin:0;padding:0;font-size:.88em;}
.omw-day li{display:flex;justify-content:space-between;gap:1em;padding:.15em 0;}
.omw-day li span{color:#475569;}
.omw-charts{margin:0 0 1em;}
.omw-chart-variant{display:none;}
.omw-chart-variant.is-active{display:block;}
.omw-chart{margin:0 0 .8em;background:#fff;border:1px solid #e2e8f0;border-radius:8px;padding:.5em .6em .2em;}
.omw-chart:last-child{margin-bottom:0;}
.omw-chart figcaption{font-size:.85em;font-weight:600;color:#334155;padding:.1em .2em .3em;}
.omw-chart svg{display:block;width:100%;height:auto;}
.omw-area{fill:#6366f14d;}
.omw-line{fill:none;stroke:#4f46e5;stroke-width:2;}
.omw-bar{fill:#f59e0b;opacity:.85;}
.omw-grid{stroke:#e2e8f0;stroke-width:1;}
.omw-grid-sep{stroke:#94a3b8;stroke-width:1;stroke-dasharray:3 3;}
.omw-axis-line{stroke:#94a3b8;stroke-width:1;}
.omw-axis{font-size:13px;fill:#64748b;font-family:sans-serif;}
.omw-axis-date{font-size:12px;font-weight:600;fill:#475569;}
.omw-hit{fill:transparent;pointer-events:all;}
.omw-tooltip{display:none;position:absolute;z-index:10;background:#1e293b;color:#fff;font-size:.78em;padding:.25em .6em;border-radius:.4em;pointer-events:none;white-space:nowrap;}
.omw-tooltip.is-visible{display:block;}
.omw-period{display:flex;align-items:center;flex-wrap:wrap;gap:.4em;margin:0 0 .6em;}
.omw-period-label{font-size:.85em;color:#475569;margin-right:.2em;}
.omw-btn{font-size:.8em;padding:.25em .7em;border:1px solid #c7d2fe;border-radius:1em;background:#fff;color:#3730a3;cursor:pointer;}
.omw-btn:hover{background:#eef2ff;}
.omw-btn.is-active{background:#4f46e5;border-color:#4f46e5;color:#fff;}
.omw-table-block{margin:0 0 .6em;}
.omw-table-wrap{overflow-x:auto;-webkit-overflow-scrolling:touch;margin:0;}
.omw-table{border-collapse:collapse;width:100%;min-width:340px;font-size:.85em;background:#fff;}
.omw-table th,.omw-table td{padding:.35em .6em;text-align:right;border-bottom:1px solid #e2e8f0;white-space:nowrap;}
.omw-table thead th{background:#eef2ff;color:#3730a3;position:sticky;top:0;}
.omw-table tbody th{text-align:left;font-weight:400;color:#475569;}
.omw-attribution{font-size:.75em;color:#64748b;margin:.4em 0 0;}
.omw-widget,.omw-widget *{box-sizing:border-box;}
.omw-widget .omw-loc-label{font-size:.88em;text-align:left;}
.omw-widget .omw-days{display:flex;gap:6px;overflow-x:auto;flex-wrap:nowrap;}
.omw-widget .omw-day{flex:1 0 155px;padding:10px;min-width:155px;text-align:center;}
.omw-widget .omw-day-date{white-space:nowrap;font-size:.85em;letter-spacing:normal;word-spacing:normal;text-align:center;}
.omw-widget .omw-day li{gap:8px;white-space:nowrap;text-align:left;letter-spacing:normal;word-spacing:normal;}
.omw-widget .omw-day li strong{white-space:nowrap;text-align:right;font-variant-numeric:tabular-nums;}
.omw-widget .omw-day p,.omw-widget .omw-day ul{margin-top:0;}
.omw-widget .omw-day .omw-badge{white-space:nowrap;text-align:center;}
.omw-widget .omw-head{overflow-x:auto;margin:0 0 12px;}
.omw-widget .omw-summary{display:block;white-space:nowrap;text-align:left;margin:0;font-size:.85em;line-height:1.8;letter-spacing:normal;word-spacing:normal;}
.omw-widget .omw-location{font-weight:600;}
.omw-widget .omw-summary-meta{font-weight:400;color:#475569;}
.omw-widget .omw-forecast td,.omw-widget .omw-forecast th{color:#526174;font-style:italic;background:#f1f5f9;}
.omw-widget tr[hidden]{display:none!important;}
.omw-widget .omw-table thead th{text-align:center;}
.omw-date-status{flex-basis:100%;font-size:.8em;}
.omw-date{max-width:170px;padding:4px;}
.omw-btn:disabled{opacity:.45;cursor:not-allowed;}
.omw-future-bg{fill:#eef2ff;}
.omw-now{stroke:#475569;stroke-width:1.5;stroke-dasharray:4 3;}

.omw-widget .omw-loc-form{display:grid;grid-template-columns:auto minmax(0,1fr) auto;align-items:center;gap:8px;margin:0 0 12px;}
.omw-widget .omw-loc-label{grid-column:1;display:block;margin:0;text-align:left;white-space:nowrap;}
.omw-widget .omw-loc-input{grid-column:2;width:100%;min-width:0;margin:0;font-family:inherit;font-size:.8em;}
.omw-widget .omw-loc-btn{grid-column:3;margin:0;white-space:nowrap;}
.omw-widget .omw-loc-status{grid-column:1/-1;}
.omw-widget .omw-loc-status:empty,.omw-widget .omw-date-status:empty{display:none;}
.omw-widget .omw-date-form{display:grid;grid-template-columns:var(--omw-label-width,auto) auto minmax(0,1fr);align-items:center;gap:8px;margin:0 0 .6em;padding:0 var(--omw-end-space,0px) 0 0;}
.omw-widget .omw-period-title{grid-column:1;margin:0;font-size:.88em;white-space:nowrap;}
.omw-widget .omw-today-btn{grid-column:2;justify-self:start;margin:0;white-space:nowrap;}
.omw-widget .omw-calendar-controls{grid-column:3;display:inline-flex;align-items:center;justify-self:end;gap:4px;max-width:100%;overflow-x:auto;white-space:nowrap;}
.omw-widget .omw-calendar-controls>*{flex-shrink:0;margin:0;}
.omw-widget .omw-date{font-family:inherit;font-size:.8em;font-weight:400;line-height:normal;width:118px;min-width:0;max-width:100%;padding:3px 4px;}
.omw-widget .omw-date::-webkit-datetime-edit{font:inherit;padding:0;}
.omw-widget .omw-date::-webkit-calendar-picker-indicator{margin-left:2px;padding:1px;cursor:pointer;}
.omw-widget .omw-calendar-controls .omw-btn[data-step]{display:inline-flex;align-items:center;justify-content:center;width:26px;height:26px;min-width:26px;min-height:26px;padding:0;font-size:10px;line-height:1;border-radius:50%;}
.omw-widget .omw-date-status{grid-column:1/-1;}
@media(max-width:600px){
 .omw-widget .omw-loc-form{grid-template-columns:minmax(0,1fr) auto;}
 .omw-widget .omw-loc-label{grid-column:1/-1;white-space:normal;}
 .omw-widget .omw-loc-input{grid-column:1;font-size:14px;}
 .omw-widget .omw-loc-btn{grid-column:2;}
 .omw-widget .omw-date-form{grid-template-columns:auto minmax(0,1fr);padding-right:var(--omw-end-space,0px);}
 .omw-widget .omw-today-btn{grid-column:2;}
 .omw-widget .omw-calendar-controls{grid-column:1/-1;justify-self:end;}
 .omw-widget .omw-date{font-size:14px;}
}

CSS;
	return '<style>' . $css . '</style>';
}
