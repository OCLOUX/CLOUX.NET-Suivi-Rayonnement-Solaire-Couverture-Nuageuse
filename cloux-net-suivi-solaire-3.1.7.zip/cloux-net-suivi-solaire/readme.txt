=== CLOUX.NET Suivi solaire ===
Stable tag: 3.1.7
Requires PHP: 7.4
License: GPLv2 or later

3.1.7 : champ date réduit de 140 à 118 px ; marge de l’icône réduite
sur moteurs WebKit/Blink ; flèches de 10 px dans des boutons de 26 x 26 px ;
espacement entre les commandes de 4 px.
Conserve les changements 3.1.4 à 3.1.6 : localisation sur une ligne,
Aujourd’hui aligné au début du champ ville sur grand écran, calendrier aligné
sur la fin du champ ville, police identique, chargement automatique de date,
pas de bouton Afficher. Disposition adaptée à 600 px et moins.
Coordonnées, fuseau, rendu des données et API inchangés.

Installation : sauvegarder puis téléverser le ZIP dans Extensions > Ajouter
une extension ; remplacer la version existante, sans activer une seconde copie.
Shortcodes : [suivi_solaire] et [openmeteo_weather].
